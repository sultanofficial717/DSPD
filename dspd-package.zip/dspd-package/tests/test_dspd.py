"""
tests/test_dspd.py
─────────────────────────────────────────────────────────────────────────────
Unit tests for DSPD core algorithm.

Run with:  pytest tests/ -v
"""

import os
import pytest
from dspd.core import derive_password, hkdf_sha256, _encode


DEVICE_SECRET = os.urandom(32)   # fixed for test session


# ── HKDF tests ────────────────────────────────────────────────────────────────

def test_hkdf_output_length():
    out = hkdf_sha256(b"input", b"info", 32)
    assert len(out) == 32


def test_hkdf_deterministic():
    a = hkdf_sha256(b"same-input", b"info", 32)
    b = hkdf_sha256(b"same-input", b"info", 32)
    assert a == b


def test_hkdf_different_inputs():
    a = hkdf_sha256(b"input-one", b"info", 32)
    b = hkdf_sha256(b"input-two", b"info", 32)
    assert a != b


# ── Derivation tests ──────────────────────────────────────────────────────────

def test_derive_deterministic():
    """Same inputs always produce same password."""
    p1 = derive_password("masterkey", "github.com", DEVICE_SECRET, 1)
    p2 = derive_password("masterkey", "github.com", DEVICE_SECRET, 1)
    assert p1 == p2


def test_derive_output_length():
    p = derive_password("masterkey", "github.com", DEVICE_SECRET, 1)
    assert len(p) == 16


def test_derive_different_apps():
    """Different apps produce different passwords."""
    p1 = derive_password("masterkey", "github.com",  DEVICE_SECRET, 1)
    p2 = derive_password("masterkey", "netflix.com", DEVICE_SECRET, 1)
    assert p1 != p2


def test_derive_different_master_keys():
    """Different master keys produce different passwords."""
    p1 = derive_password("key-one", "github.com", DEVICE_SECRET, 1)
    p2 = derive_password("key-two", "github.com", DEVICE_SECRET, 1)
    assert p1 != p2


def test_derive_different_device_secrets():
    """Different device secrets produce different passwords."""
    d1 = os.urandom(32)
    d2 = os.urandom(32)
    p1 = derive_password("masterkey", "github.com", d1, 1)
    p2 = derive_password("masterkey", "github.com", d2, 1)
    assert p1 != p2


def test_derive_version_rotation():
    """Incrementing version changes the password."""
    p1 = derive_password("masterkey", "github.com", DEVICE_SECRET, 1)
    p2 = derive_password("masterkey", "github.com", DEVICE_SECRET, 2)
    assert p1 != p2


def test_derive_version_isolation():
    """Rotating one app does not affect another."""
    github_v1   = derive_password("masterkey", "github.com",  DEVICE_SECRET, 1)
    netflix_v1  = derive_password("masterkey", "netflix.com", DEVICE_SECRET, 1)
    github_v2   = derive_password("masterkey", "github.com",  DEVICE_SECRET, 2)
    netflix_v1b = derive_password("masterkey", "netflix.com", DEVICE_SECRET, 1)

    assert github_v1  != github_v2     # github changed
    assert netflix_v1 == netflix_v1b   # netflix unchanged


def test_derive_app_name_case_insensitive():
    """App name is normalized to lowercase."""
    p1 = derive_password("masterkey", "GitHub.COM", DEVICE_SECRET, 1)
    p2 = derive_password("masterkey", "github.com", DEVICE_SECRET, 1)
    assert p1 == p2


def test_derive_invalid_empty_master_key():
    with pytest.raises(ValueError, match="master_key"):
        derive_password("", "github.com", DEVICE_SECRET, 1)


def test_derive_invalid_empty_app_name():
    with pytest.raises(ValueError, match="app_name"):
        derive_password("masterkey", "", DEVICE_SECRET, 1)


def test_derive_invalid_device_secret_length():
    with pytest.raises(ValueError, match="32 bytes"):
        derive_password("masterkey", "github.com", b"tooshort", 1)


def test_derive_invalid_version():
    with pytest.raises(ValueError, match="version"):
        derive_password("masterkey", "github.com", DEVICE_SECRET, 0)


# ── Encoder tests ─────────────────────────────────────────────────────────────

def test_encode_output_length():
    raw = os.urandom(32)
    assert len(_encode(raw)) == 16


def test_encode_policy_compliance():
    """Output must contain at least one char from each required class."""
    import string
    for _ in range(20):   # test multiple random inputs
        raw = os.urandom(32)
        pw  = _encode(raw)
        assert any(c in string.ascii_uppercase for c in pw), f"No uppercase in {pw}"
        assert any(c in string.ascii_lowercase for c in pw), f"No lowercase in {pw}"
        assert any(c in string.digits          for c in pw), f"No digit in {pw}"
        assert any(c in "!@#$%^&*"            for c in pw), f"No symbol in {pw}"


# ── Manager tests ─────────────────────────────────────────────────────────────

def test_manager_get_password():
    from dspd import DSPDManager
    mgr = DSPDManager()
    pw  = mgr.get_password("testapp.com", "test-master-key")
    assert isinstance(pw, str)
    assert len(pw) == 16


def test_manager_rotate():
    from dspd import DSPDManager
    mgr  = DSPDManager()
    pw1  = mgr.get_password("rotatetest.com", "test-key")
    result = mgr.rotate_password("rotatetest.com", "test-key")
    pw2  = result["new_password"]
    assert pw1 != pw2
    assert result["new_version"] == result["old_version"] + 1
