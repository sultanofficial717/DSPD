"""
dspd/cli.py
─────────────────────────────────────────────────────────────────────────────
Command-line interface for DSPD.

Commands
--------
  dspd get <app>            Derive and copy password for an app
  dspd rotate <app>         Rotate password for a single app
  dspd list                 List all apps with custom version counters
  dspd version <app>        Show current version counter for an app
  dspd backup               Export device secret as base64 (for backup)
  dspd restore <b64>        Restore device secret from backup string
  dspd init                 Initialize device secret (first-time setup)
  dspd benchmark            Run Argon2id performance benchmark
"""

import sys
import time
import getpass
import argparse

from .manager import DSPDManager
from .device  import (
    export_device_secret_base64,
    import_device_secret_base64,
    device_secret_exists,
    get_device_secret,
)
from .core import derive_password


# ── Helpers ───────────────────────────────────────────────────────────────────

def _prompt_master_key() -> str:
    """Securely prompt for master key (hidden input)."""
    key = getpass.getpass("  Enter master key: ")
    if not key:
        print("[ERROR] Master key cannot be empty.")
        sys.exit(1)
    return key


def _print_banner():
    print()
    print("  ██████╗ ███████╗██████╗ ██████╗ ")
    print("  ██╔══██╗██╔════╝██╔══██╗██╔══██╗")
    print("  ██║  ██║███████╗██████╔╝██║  ██║")
    print("  ██║  ██║╚════██║██╔═══╝ ██║  ██║")
    print("  ██████╔╝███████║██║     ██████╔╝")
    print("  ╚═════╝ ╚══════╝╚═╝     ╚═════╝ ")
    print("  Device-Bound Stateless Password Derivation")
    print("  Author: Talha R. | Bahria University Islamabad")
    print()


# ── Commands ──────────────────────────────────────────────────────────────────

def cmd_get(args):
    """Derive password for an app."""
    app = args.app
    print(f"\n  [DSPD] Deriving password for: {app}")
    master_key = _prompt_master_key()

    mgr = DSPDManager()
    version  = mgr.get_version(app)
    password = mgr.get_password(app, master_key)

    print(f"\n  App      : {app}")
    print(f"  Version  : {version}")
    print(f"  Password : {password}")

    # Try to copy to clipboard
    try:
        import subprocess
        if sys.platform == "win32":
            subprocess.run(["clip"], input=password.encode(), check=True)
            print("\n  [✓] Password copied to clipboard.")
        elif sys.platform == "darwin":
            subprocess.run(["pbcopy"], input=password.encode(), check=True)
            print("\n  [✓] Password copied to clipboard.")
        else:
            try:
                subprocess.run(["xclip", "-selection", "clipboard"],
                               input=password.encode(), check=True)
                print("\n  [✓] Password copied to clipboard.")
            except FileNotFoundError:
                print("\n  [i] Install xclip for clipboard support.")
    except Exception:
        pass

    # Clear master key from memory
    master_key = "\x00" * len(master_key)
    print()


def cmd_rotate(args):
    """Rotate password for a single app."""
    app = args.app
    print(f"\n  [DSPD] Rotating password for: {app}")
    print( "  WARNING: Update your password on the site BEFORE confirming.")
    confirm = input("  Type 'yes' to confirm rotation: ").strip().lower()
    if confirm != "yes":
        print("  Cancelled.")
        return

    master_key = _prompt_master_key()
    mgr    = DSPDManager()
    result = mgr.rotate_password(app, master_key)

    print(f"\n  App          : {result['app_name']}")
    print(f"  Old version  : {result['old_version']}")
    print(f"  New version  : {result['new_version']}")
    print(f"  New password : {result['new_password']}")
    print("\n  [✓] Version counter updated. Old password is no longer derivable.")
    print()


def cmd_list(args):
    """List apps with custom version counters."""
    mgr   = DSPDManager()
    apps  = mgr.list_apps()
    print("\n  Registered apps (version > 1):")
    if not apps:
        print("  (none — all apps are using version 1)")
    else:
        for app, ver in sorted(apps.items()):
            print(f"    {app:<30}  v{ver}")
    print()


def cmd_version(args):
    """Show version counter for an app."""
    mgr = DSPDManager()
    ver = mgr.get_version(args.app)
    print(f"\n  {args.app}  →  version {ver}\n")


def cmd_backup(args):
    """Export device secret as base64."""
    print("\n  [DSPD] Device Secret Backup")
    print("  ─────────────────────────────────────────────────────────────")
    print("  WARNING: Store this string securely (printed paper / USB).")
    print("  Anyone with this string + your master key can derive ALL passwords.")
    print()
    confirm = input("  Type 'yes' to reveal backup string: ").strip().lower()
    if confirm != "yes":
        print("  Cancelled.")
        return
    b64 = export_device_secret_base64()
    print(f"\n  BACKUP STRING:\n\n  {b64}\n")


def cmd_restore(args):
    """Restore device secret from backup string."""
    print("\n  [DSPD] Restoring device secret from backup...")
    try:
        import_device_secret_base64(args.backup_string)
        print("  [✓] Device secret restored successfully.\n")
    except Exception as e:
        print(f"  [ERROR] Restore failed: {e}\n")
        sys.exit(1)


def cmd_init(args):
    """Initialize DSPD on this device."""
    if device_secret_exists():
        print("\n  [i] DSPD is already initialized on this device.")
        print("  Use 'dspd backup' to export your device secret.\n")
        return
    print("\n  [DSPD] Initializing device secret...")
    get_device_secret()   # triggers generation
    print("  [✓] Device secret generated and stored in secure storage.")
    print("  Run 'dspd backup' to create a recovery backup.\n")


def cmd_benchmark(args):
    """Run Argon2id performance benchmark."""
    import os as _os
    import argon2.low_level as _a

    print("\n  [DSPD] Argon2id Performance Benchmark")
    print("  Parameters: t=3, m=65536 (64MB), p=2")
    print("  Running 5 iterations...\n")

    key  = b"benchmark-master-key-test"
    salt = _os.urandom(32)
    times = []

    for i in range(5):
        t0 = time.perf_counter()
        _a.hash_secret_raw(
            secret=key, salt=salt,
            time_cost=3, memory_cost=65536,
            parallelism=2, hash_len=32,
            type=_a.Type.ID
        )
        elapsed = (time.perf_counter() - t0) * 1000
        times.append(elapsed)
        print(f"    Run {i+1}: {elapsed:.1f} ms")

    avg = sum(times) / len(times)
    print(f"\n  Average : {avg:.1f} ms")
    print(f"  Min     : {min(times):.1f} ms")
    print(f"  Max     : {max(times):.1f} ms")
    print()

    if avg < 500:
        print("  [✓] Excellent — well within user-acceptable latency.")
    elif avg < 1500:
        print("  [✓] Acceptable performance.")
    else:
        print("  [!] Slow device — consider reducing memory_cost for this platform.")
    print()


# ── Entry Point ───────────────────────────────────────────────────────────────

def main():
    _print_banner()

    parser = argparse.ArgumentParser(
        prog="dspd",
        description="DSPD — Device-Bound Stateless Password Derivation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", metavar="<command>")

    # get
    p_get = sub.add_parser("get", help="Derive password for an app")
    p_get.add_argument("app", help="App/site name (e.g. github.com)")

    # rotate
    p_rot = sub.add_parser("rotate", help="Rotate password for an app")
    p_rot.add_argument("app", help="App/site name")

    # list
    sub.add_parser("list", help="List all registered apps")

    # version
    p_ver = sub.add_parser("version", help="Show version counter for an app")
    p_ver.add_argument("app", help="App/site name")

    # backup
    sub.add_parser("backup", help="Export device secret as base64 backup")

    # restore
    p_res = sub.add_parser("restore", help="Restore device secret from backup")
    p_res.add_argument("backup_string", help="Base64 backup string")

    # init
    sub.add_parser("init", help="Initialize DSPD on this device")

    # benchmark
    sub.add_parser("benchmark", help="Run Argon2id performance benchmark")

    args = parser.parse_args()

    commands = {
        "get":       cmd_get,
        "rotate":    cmd_rotate,
        "list":      cmd_list,
        "version":   cmd_version,
        "backup":    cmd_backup,
        "restore":   cmd_restore,
        "init":      cmd_init,
        "benchmark": cmd_benchmark,
    }

    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
