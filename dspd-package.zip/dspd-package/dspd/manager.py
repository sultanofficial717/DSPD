"""
dspd/manager.py
─────────────────────────────────────────────────────────────────────────────
High-level DSPD password manager API.

This is the main interface developers integrate into their applications.

Usage
-----
    from dspd import DSPDManager

    mgr = DSPDManager()
    password = mgr.get_password("github.com", master_key="my-passphrase")
    print(password)   # e.g. "aK9#mZxQ2!vBnLpW"
"""

from .core         import derive_password
from .device       import get_device_secret, device_secret_exists
from .version_store import get_version, rotate, list_versions, reset_version


class DSPDManager:
    """
    DSPD Password Manager.

    Combines device secret management, version tracking, and
    Argon2id-based password derivation into a single clean interface.
    """

    def __init__(self):
        # Ensure device secret is initialized on first use
        self._device_secret = get_device_secret()

    # ── Core operations ───────────────────────────────────────────────────────

    def get_password(self, app_name: str, master_key: str) -> str:
        """
        Derive the current password for an application.

        Parameters
        ----------
        app_name   : Site or app identifier (e.g. "github.com", "netflix")
        master_key : User's single master passphrase

        Returns
        -------
        16-character derived password string.
        """
        version = get_version(app_name)
        return derive_password(
            master_key    = master_key,
            app_name      = app_name,
            device_secret = self._device_secret,
            version       = version,
        )

    def rotate_password(self, app_name: str, master_key: str) -> dict:
        """
        Rotate the password for a single application.

        Increments the version counter for app_name only.
        All other apps retain their existing passwords.

        Returns
        -------
        dict with keys: app_name, old_version, new_version, new_password
        """
        old_version  = get_version(app_name)
        new_version  = rotate(app_name)
        new_password = derive_password(
            master_key    = master_key,
            app_name      = app_name,
            device_secret = self._device_secret,
            version       = new_version,
        )
        return {
            "app_name":     app_name,
            "old_version":  old_version,
            "new_version":  new_version,
            "new_password": new_password,
        }

    def get_version(self, app_name: str) -> int:
        """Return the current version counter for an app."""
        return get_version(app_name)

    def list_apps(self) -> dict:
        """List all apps that have non-default (>1) version counters."""
        return list_versions()

    def reset_app(self, app_name: str) -> None:
        """Reset an app's version counter back to 1."""
        reset_version(app_name)

    # ── Device secret info ────────────────────────────────────────────────────

    def is_initialized(self) -> bool:
        """Returns True if the device secret has been set up."""
        return device_secret_exists()
