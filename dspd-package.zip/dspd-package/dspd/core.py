"""
dspd/core.py
─────────────────────────────────────────────────────────────────────────────
Core DSPD cryptographic algorithm.

Algorithm:
  1. salt = HKDF-SHA256(IKM = app_name || "." || version,
                        info = "DSPD-salt-v1",
                        length = 32)
  2. derived = Argon2id(password = master_key,
                        salt     = salt XOR device_secret,
                        t=3, m=65536, p=2, taglen=32)
  3. output  = encode(derived[:16])  →  16 printable characters

Author : Talha R.
Paper  : DSPD: A Device-Bound Stateless Password Derivation Scheme
"""

import os
import string
import hashlib
import hmac
import struct

import argon2.low_level as _argon2


# ── Constants ─────────────────────────────────────────────────────────────────

ARGON2_TIME_COST    = 3
ARGON2_MEMORY_COST  = 65536   # 64 MB
ARGON2_PARALLELISM  = 2
ARGON2_HASH_LENGTH  = 32
HKDF_INFO           = b"DSPD-salt-v1"
HKDF_LENGTH         = 32
OUTPUT_LENGTH       = 16

# Character set that satisfies most site password policies
_CHARSET = (
    string.ascii_uppercase +   # A–Z
    string.ascii_lowercase +   # a–z
    string.digits +            # 0–9
    "!@#$%^&*"                 # symbols
)

# ── HKDF-SHA256 (RFC 5869) ────────────────────────────────────────────────────

def _hkdf_extract(salt: bytes, ikm: bytes) -> bytes:
    """HKDF Extract step."""
    return hmac.new(salt, ikm, hashlib.sha256).digest()


def _hkdf_expand(prk: bytes, info: bytes, length: int) -> bytes:
    """HKDF Expand step."""
    okm = b""
    t   = b""
    i   = 1
    while len(okm) < length:
        t   = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        okm += t
        i   += 1
    return okm[:length]


def hkdf_sha256(ikm: bytes, info: bytes, length: int = HKDF_LENGTH) -> bytes:
    """
    Full HKDF-SHA256 with a zero salt (deterministic derivation).
    Using a zero salt is intentional: randomness is provided by the
    device secret in the Argon2id step.
    """
    zero_salt = bytes(32)
    prk = _hkdf_extract(zero_salt, ikm)
    return _hkdf_expand(prk, info, length)


# ── Encoder ───────────────────────────────────────────────────────────────────

def _encode(raw_bytes: bytes) -> str:
    """
    Map 16 bytes to a 16-character password using the DSPD character set.
    Each byte selects one character from _CHARSET (len=70).
    Guarantees at least one uppercase, one lowercase, one digit, one symbol.
    """
    charset_len = len(_CHARSET)
    chars = [_CHARSET[b % charset_len] for b in raw_bytes[:OUTPUT_LENGTH]]

    # Guarantee policy compliance: inject one of each required class
    # at deterministic positions (positions 0,1,2,3) based on byte values
    replacements = [
        (raw_bytes[0]  % OUTPUT_LENGTH, string.ascii_uppercase[raw_bytes[16] % 26]),
        (raw_bytes[1]  % OUTPUT_LENGTH, string.ascii_lowercase[raw_bytes[17] % 26]),
        (raw_bytes[2]  % OUTPUT_LENGTH, string.digits[raw_bytes[18] % 10]),
        (raw_bytes[3]  % OUTPUT_LENGTH, "!@#$%^&*"[raw_bytes[19] % 8]),
    ]
    for pos, ch in replacements:
        chars[pos] = ch

    return "".join(chars)


# ── Main DSPD Derivation ─────────────────────────────────────────────────────

def derive_password(
    master_key:    str,
    app_name:      str,
    device_secret: bytes,
    version:       int = 1,
) -> str:
    """
    Derive a deterministic, device-bound password.

    Parameters
    ----------
    master_key    : The user's single remembered passphrase.
    app_name      : Canonical application/site name (e.g. "github.com").
    device_secret : 32-byte secret from secure hardware storage.
    version       : Per-app rotation counter. Increment to rotate password.

    Returns
    -------
    A 16-character password string.

    Raises
    ------
    ValueError : If inputs are invalid.
    """
    if not master_key:
        raise ValueError("master_key must not be empty.")
    if not app_name:
        raise ValueError("app_name must not be empty.")
    if len(device_secret) != 32:
        raise ValueError("device_secret must be exactly 32 bytes.")
    if version < 1:
        raise ValueError("version must be >= 1.")

    # Step 1 — Deterministic salt via HKDF-SHA256
    ikm  = f"{app_name.lower().strip()}.{version}".encode("utf-8")
    salt = hkdf_sha256(ikm, HKDF_INFO, HKDF_LENGTH)

    # Step 2 — Bind salt to device secret
    effective_salt = bytes(a ^ b for a, b in zip(salt, device_secret))

    # Step 3 — Argon2id derivation
    derived = _argon2.hash_secret_raw(
        secret      = master_key.encode("utf-8"),
        salt        = effective_salt,
        time_cost   = ARGON2_TIME_COST,
        memory_cost = ARGON2_MEMORY_COST,
        parallelism = ARGON2_PARALLELISM,
        hash_len    = ARGON2_HASH_LENGTH,
        type        = _argon2.Type.ID,
    )

    # Step 4 — Encode to human-readable password
    return _encode(derived)
