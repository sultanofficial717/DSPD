"""
dspd/device.py
─────────────────────────────────────────────────────────────────────────────
Device secret management.

Stores a 32-byte random secret in the OS-native secure keystore:
  - Windows  : Windows Credential Manager
  - macOS    : Keychain
  - Linux    : SecretService (GNOME Keyring / KWallet)

The secret is generated once on first use and never leaves secure storage.
"""

import os
import base64

try:
    import keyring
    _KEYRING_AVAILABLE = True
except ImportError:
    _KEYRING_AVAILABLE = False

_SERVICE_NAME = "DSPD-PasswordDerivation"
_SECRET_KEY   = "device-secret-v1"
_FALLBACK_DIR = os.path.join(os.path.expanduser("~"), ".dspd")
_FALLBACK_FILE = os.path.join(_FALLBACK_DIR, "device_secret.bin")


def _load_from_keyring() -> bytes | None:
    """Attempt to load device secret from OS keyring."""
    try:
        val = keyring.get_password(_SERVICE_NAME, _SECRET_KEY)
        if val:
            return base64.b64decode(val)
    except Exception:
        pass
    return None


def _save_to_keyring(secret: bytes) -> bool:
    """Attempt to save device secret to OS keyring."""
    try:
        keyring.set_password(_SERVICE_NAME, _SECRET_KEY, base64.b64encode(secret).decode())
        return True
    except Exception:
        return False


def _load_from_fallback() -> bytes | None:
    """Load from encrypted file fallback (when keyring unavailable)."""
    if os.path.exists(_FALLBACK_FILE):
        try:
            with open(_FALLBACK_FILE, "rb") as f:
                return f.read()
        except Exception:
            pass
    return None


def _save_to_fallback(secret: bytes) -> None:
    """Save to file fallback with restricted permissions."""
    os.makedirs(_FALLBACK_DIR, exist_ok=True)
    with open(_FALLBACK_FILE, "wb") as f:
        f.write(secret)
    # Restrict to owner read/write only (Unix systems)
    try:
        os.chmod(_FALLBACK_FILE, 0o600)
        os.chmod(_FALLBACK_DIR,  0o700)
    except Exception:
        pass   # Windows doesn't support chmod — Credential Manager handles it


def get_device_secret() -> bytes:
    """
    Retrieve the device secret from secure storage.
    If no secret exists, generates and stores a new one.

    Returns a 32-byte secret.
    """
    # 1. Try OS keyring first
    if _KEYRING_AVAILABLE:
        secret = _load_from_keyring()
        if secret and len(secret) == 32:
            return secret

    # 2. Fall back to restricted file
    secret = _load_from_fallback()
    if secret and len(secret) == 32:
        return secret

    # 3. First run — generate new device secret
    return _generate_new_device_secret()


def _generate_new_device_secret() -> bytes:
    """Generate a fresh cryptographically random 32-byte device secret."""
    secret = os.urandom(32)

    saved_to_keyring = False
    if _KEYRING_AVAILABLE:
        saved_to_keyring = _save_to_keyring(secret)

    if not saved_to_keyring:
        _save_to_fallback(secret)

    return secret


def device_secret_exists() -> bool:
    """Check whether a device secret has already been initialized."""
    if _KEYRING_AVAILABLE and _load_from_keyring():
        return True
    return os.path.exists(_FALLBACK_FILE)


def delete_device_secret() -> None:
    """
    Permanently delete the device secret.
    WARNING: All derived passwords will be permanently unrecoverable after this.
    """
    if _KEYRING_AVAILABLE:
        try:
            keyring.delete_password(_SERVICE_NAME, _SECRET_KEY)
        except Exception:
            pass

    if os.path.exists(_FALLBACK_FILE):
        # Overwrite before deleting (basic secure erase)
        with open(_FALLBACK_FILE, "wb") as f:
            f.write(os.urandom(32))
        os.remove(_FALLBACK_FILE)


def export_device_secret_base64() -> str:
    """
    Export device secret as base64 for backup purposes.
    Store this in a physically secure location (e.g. printed paper, USB).
    """
    return base64.b64encode(get_device_secret()).decode()


def import_device_secret_base64(b64_secret: str) -> None:
    """
    Restore a device secret from a base64 backup string.
    Used when migrating to a new device.
    """
    secret = base64.b64decode(b64_secret)
    if len(secret) != 32:
        raise ValueError("Invalid backup: secret must be 32 bytes.")

    saved = False
    if _KEYRING_AVAILABLE:
        saved = _save_to_keyring(secret)
    if not saved:
        _save_to_fallback(secret)
