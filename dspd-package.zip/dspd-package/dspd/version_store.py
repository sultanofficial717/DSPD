"""
dspd/version_store.py
─────────────────────────────────────────────────────────────────────────────
Persistent version counter storage.

Maps app identifiers → version integers.
Stored as a simple JSON file in ~/.dspd/versions.json
"""

import json
import os

_STORE_DIR  = os.path.join(os.path.expanduser("~"), ".dspd")
_STORE_FILE = os.path.join(_STORE_DIR, "versions.json")


def _load() -> dict:
    if os.path.exists(_STORE_FILE):
        try:
            with open(_STORE_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save(data: dict) -> None:
    os.makedirs(_STORE_DIR, exist_ok=True)
    with open(_STORE_FILE, "w") as f:
        json.dump(data, f, indent=2)
    try:
        os.chmod(_STORE_FILE, 0o600)
    except Exception:
        pass


def get_version(app_name: str) -> int:
    """Get current version for an app. Returns 1 if not set."""
    return _load().get(app_name.lower().strip(), 1)


def set_version(app_name: str, version: int) -> None:
    """Manually set version for an app."""
    if version < 1:
        raise ValueError("Version must be >= 1.")
    data = _load()
    data[app_name.lower().strip()] = version
    _save(data)


def rotate(app_name: str) -> int:
    """
    Increment version counter for app_name by 1.
    This changes that app's derived password without affecting others.
    Returns the new version number.
    """
    data    = _load()
    key     = app_name.lower().strip()
    new_ver = data.get(key, 1) + 1
    data[key] = new_ver
    _save(data)
    return new_ver


def list_versions() -> dict:
    """Return all stored app → version mappings."""
    return _load()


def reset_version(app_name: str) -> None:
    """Reset an app's version back to 1."""
    data = _load()
    data.pop(app_name.lower().strip(), None)
    _save(data)
