"""
DSPD — Device-Bound Stateless Password Derivation
==================================================

A novel password derivation scheme that eliminates the need for any
password database while binding derived credentials to a hardware-resident
device secret.

Algorithm
---------
  salt     = HKDF-SHA256(app_name || version, "DSPD-salt-v1")
  derived  = Argon2id(master_key, salt XOR device_secret, t=3, m=64MB, p=2)
  password = encode(derived[:16])

Quick Start
-----------
  from dspd import DSPDManager

  mgr = DSPDManager()
  pw  = mgr.get_password("github.com", master_key="my-passphrase")
  print(pw)

CLI
---
  dspd get github.com
  dspd rotate netflix
  dspd backup

Author : Talha R.
Paper  : DSPD: A Device-Bound Stateless Password Derivation Scheme
         with Version-Controlled Rotation for Multi-Platform Environments
"""

__version__   = "1.0.0"
__author__    = "Talha R."
__email__     = ""
__license__   = "MIT"

from .manager       import DSPDManager
from .core          import derive_password, hkdf_sha256
from .device        import (
    get_device_secret,
    export_device_secret_base64,
    import_device_secret_base64,
    device_secret_exists,
    delete_device_secret,
)
from .version_store import get_version, rotate, list_versions, reset_version

__all__ = [
    "DSPDManager",
    "derive_password",
    "hkdf_sha256",
    "get_device_secret",
    "export_device_secret_base64",
    "import_device_secret_base64",
    "device_secret_exists",
    "delete_device_secret",
    "get_version",
    "rotate",
    "list_versions",
    "reset_version",
]
